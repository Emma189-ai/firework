const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

class Firework {
  constructor() {
    this.reset();
  }

  reset() {
    this.x = Math.random() * canvas.width;
    this.y = canvas.height;
    this.targetY = Math.random() * canvas.height / 2;
    this.color = `hsl(${Math.random() * 360}, 100%, 70%)`;
    this.exploded = false;
    this.particles = [];
  }

  update() {
    if (!this.exploded) {
      this.y -= 5;
      if (this.y < this.targetY) {
        this.exploded = true;
        for (let i = 0; i < 100; i++) {
          this.particles.push(new Particle(this.x, this.y, this.color));
        }
      }
    }
    this.particles.forEach(p => p.update());
  }

  draw() {
    if (!this.exploded) {
      ctx.beginPath();
      ctx.arc(this.x, this.y, 2, 0, Math.PI * 2);
      ctx.fillStyle = this.color;
      ctx.fill();
    }
    this.particles.forEach(p => p.draw());
  }
}

class Particle {
  constructor(x, y, color) {
    this.x = x;
    this.y = y;
    this.velX = (Math.random() - 0.5) * 5;
    this.velY = (Math.random() - 0.5) * 5;
    this.alpha = 1;
    this.color = color;
  }

  update() {
    this.x += this.velX;
    this.y += this.velY;
    this.alpha -= 0.01;
  }

  draw() {
    ctx.globalAlpha = this.alpha;
    ctx.beginPath();
    ctx.arc(this.x, this.y, 2, 0, Math.PI * 2);
    ctx.fillStyle = this.color;
    ctx.fill();
    ctx.globalAlpha = 1;
  }
}

let fireworks = [];
setInterval(() => {
  fireworks.push(new Firework());
}, 600);

function animate() {
  ctx.fillStyle = "rgba(0, 0, 30, 0.2)";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  fireworks.forEach(fw => {
    fw.update();
    fw.draw();
  });
  fireworks = fireworks.filter(fw => !fw.exploded || fw.particles.some(p => p.alpha > 0));
  requestAnimationFrame(animate);
}

animate();
